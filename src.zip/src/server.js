import express from 'express'
import{CONNECT_DB, GET_DB} from'~/config/mongodb'
import { env } from '~/config/environment'
import { APIs_v1 } from '~/routes/v1'

const START_SERVER = () => {
  const app = express()
  const hostname = 'localhost'
  const port = 8081
  // enable request body
  app.use(express.json())
  //su dung api v1
  app.use('/v1', APIs_v1)

  app.listen(port, hostname, () => {
    // eslint-disable-next-line no-console
    console.log(`CodeUp đang được chạy ${env.AUTHOR} http://${ hostname }:${ port }`)
  })
}

CONNECT_DB() 
.then(() => console.log('Kết nối tới MongoDB thành công'))
.then(() => START_SERVER())
.catch(error => {console.error(error)
  process.exit(0)
})