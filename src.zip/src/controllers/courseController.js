import { StatusCodes } from "http-status-codes";

const createNew = async (req, res, next) => {
    try {
        console.log('req.body:',req.body)
        console.log('req.query:',req.query)
        console.log('req.params:',req.params)
        console.log('req.files:',req.files)
        console.log('req.cookies:',req.cookies)

        //Điều hướng dữ liệu sang tầng service

        //Có kết quả sẽ trả về cho client
        res.status(StatusCodes.CREATED).json({message: 'POST Controller API new courses'});
    } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            message: 'Internal Server Error',
            error: error.message,
        });
    }
}

export const courseController = {
    createNew,
}
