import mongoose from 'mongoose';

const lessonSchema = new mongoose.Schema({
  title: String,
  videoUrl: String,
  content: String
});

export const LessonModel = mongoose.model('Lesson', lessonSchema);