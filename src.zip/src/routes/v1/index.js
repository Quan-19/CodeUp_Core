import expess from 'express';
import{StatusCodes} from 'http-status-codes'
import { CourseRoute } from '~/routes/v1/CourseRoute.js';
import { UserRoute } from '~/routes/v1/UserRoute';
import { AdminRoute } from '~/routes/v1/adminRoute';

const Router = expess.Router();

//check APTs_v1/home
Router.get('/home', (req, res) => {
  res.status(StatusCodes.OK).json({message: 'OK'});
})

Router.use('/courses', CourseRoute);
Router.use('/users', UserRoute);
Router.use('/admin', AdminRoute);

export const APIs_v1 = Router