import express from 'express';
import { createCourse, updateCourse, deleteCourse, addLesson, getStatistics } from '~/controllers/adminController';

const router = express.Router();

router.post('/courses', createCourse);
router.put('/courses/:id', updateCourse);
router.delete('/courses/:id', deleteCourse);
router.post('/courses/:id/lessons', addLesson);
router.get('/statistics', getStatistics);

export const AdminRoute = router;