import expess from 'express';
import{StatusCodes} from 'http-status-codes'
import { courseController } from '~/controllers/courseController';
import { courseValidation } from '~/validations/courseValidation';
const Router = expess.Router();

Router.route('/')
    .get((req, res)=> {
    res.status(StatusCodes.OK).json({message: 'API get list courses'});
    })
    .post(courseValidation.createNew, courseController.createNew)

export const CourseRoute = Router