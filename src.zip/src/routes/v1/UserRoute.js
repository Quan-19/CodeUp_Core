import express from 'express';
import { buyCourse, getUserCourses, learnCourse } from '~/controllers/userController';

const router = express.Router();

router.get('/:id/courses', getUserCourses);
router.post('/buy', buyCourse);
router.get('/learning/:courseId', learnCourse);

export const UserRoute = router;