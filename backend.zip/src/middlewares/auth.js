exports.authenticate = async (req, res, next) => {
  try {
    const authHeader = req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Token không hợp lệ hoặc không được cung cấp.' });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const userId = decoded.userId;
    const role = decoded.role;

    let userModel;
    switch (role) {
      case 'student':
        userModel = mongoose.model('User');
        break;
      case 'instructor':
        userModel = mongoose.model('Instructor');
        break;
      case 'admin':
        userModel = mongoose.model('Admin');
        break;
      default:
        return res.status(400).json({ message: 'Vai trò không hợp lệ' });
    }

    const user = await userModel.findById(userId);
    if (!user) {
      return res.status(401).json({ message: 'Không tìm thấy người dùng' });
    }

    req.user = user;
    req.user.id = user._id;
    req.user.role = role;

    next();
  } catch (err) {
    console.error("Authentication error:", err);
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ message: 'Token đã hết hạn. Vui lòng đăng nhập lại.' });
    }
    res.status(401).json({ message: 'Vui lòng đăng nhập' });
  }
};
