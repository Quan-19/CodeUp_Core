const mongoose = require("mongoose");

const CourseSchema = new mongoose.Schema({
  title: String,
  description: String,
  category: String,
  level: String,
  price: Number,
  duration: Number,
  imageUrl: String,
  instructor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  content: [
    {
      title: String,
      description: String,
      videoUrl: String,
    },
  ],
}, { timestamps: true });

module.exports = mongoose.model("Course", CourseSchema);