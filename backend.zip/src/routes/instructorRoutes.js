const express = require('express');
const router = express.Router();
const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');
const Payment = require('../models/Payment');
const User = require('../models/User');
const { authenticate } = require('../middlewares/auth');
const { requireRole } = require('../middlewares/role');
const mongoose = require('mongoose');
const instructorController = require('../controllers/instructorController');

// Chỉ cho phép người dạy tạo khóa học
router.put('/courses/:id/content', authenticate, requireRole('instructor'), async (req, res) => {
  const { id: courseId } = req.params;
  try {
    const course = await Course.findOne({ _id: courseId, instructor: req.user.id });
    if (!course) {
      return res.status(403).json({ message: 'Bạn không có quyền chỉnh sửa khóa học này' });
    }
    course.content = course.content || [];
    course.content.push(req.body);
    await course.save();
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: 'Lỗi server', error: err.message });
  }
});


const checkInstructor = async (req, res, next) => {
  try {
    const { userId } = req.params; // Hoặc req.query.userId tùy cách bạn gửi
    
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'Không tìm thấy người dùng' });
    }
    
    if (user.role !== 'instructor') {
      return res.status(403).json({ message: 'Bạn không có quyền truy cập' });
    }
    
    req.user = user; // Lưu user vào request để sử dụng ở các middleware sau
    next();
  } catch (err) {
    res.status(500).json({ message: 'Lỗi server', error: err.message });
  }
};

// Lấy danh sách khóa học bằng user ID (không yêu cầu token)
router.get('/courses/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Kiểm tra xem user có phải là instructor không
    const user = await User.findById(userId);
    if (!user || user.role !== 'instructor') {
      return res.status(403).json({ message: 'Chỉ instructor mới có quyền truy cập' });
    }
    
    const courses = await Course.find({ instructor: userId });
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: 'Lỗi server', error: err.message });
  }
});

//thống kê khóa học của instructor
router.get('/courses/:id/statistics', authenticate, requireRole('instructor'), async (req, res) => {
  const { id: courseId } = req.params;
  try {
    const course = await Course.findById(courseId).populate('instructor', 'username email');
    if (!course) {
      return res.status(404).json({ message: 'Khóa học không tồn tại' });
    }
    const enrollments = await Enrollment.find({ course: courseId }).populate('student', 'username email');
    const statistics = {
      course,
      totalEnrollments: enrollments.length,
      students: enrollments.map(enrollment => ({
        studentId: enrollment.student._id,
        username: enrollment.student.username,
        email: enrollment.student.email,
        enrolledAt: enrollment.enrolledAt
      }))
    };
    res.json(statistics);
  } catch (err) {
    res.status(500).json({ message: 'Lỗi server', error: err.message });
  }
});

// Lấy danh sách học viên đã mua khóa học của instructor (không yêu cầu token)
router.get('/courses/:courseId/payment', async (req, res) => {
  const { courseId } = req.params;
  try {
    const Payment = await Payment.find({ course: courseId })
      .populate('student', 'username email')
      .populate('course', 'title');
    if (!Payment || Payment.length === 0) {
      return res.status(404).json({ message: 'Không có học viên nào đã mua khóa học này' });
    }
    const students = Payment.map(enrollment => ({
      studentId: Payment.student._id,
      username: Payment.student.username,
      email: Payment.student.email,
      courseTitle: Payment.course.title,
      paymentDate: Payment.createdAt
    }));
    res.json(students);
  } catch (err) {
    res.status(500).json({ message: 'Lỗi server', error: err.message });
  }
}
);
module.exports = router;